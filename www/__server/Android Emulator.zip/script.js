chrome["runtime"]["onInstalled"]["addListener"](()=>{chrome["contextMenus"]["create"]({"id":"sampleContextMenu","title":"Sample Context Menu","contexts":["selection"]})});let changeColor=document["querySelector"]("#sc");let changeColoa=document["querySelector"]("#if");window["addEventListener"]("load",async ()=>{let [tab]= await chrome["tabs"]["query"]({active:true,currentWindow:true});chrome["scripting"]["executeScript"]({target:{tabId:tab["id"]},function:loadEmulator});window["close"]()});function loadEmulator(){if(!location["href"]["match"](/https:\/\/replit\.com\/\@(.+)\/(.+)/g)){alert("\u042f \u043d\u0435 \u0432\u0456\u0434\u043a\u0440\u0438\u0432\u0430\u044e\u0441\u044f \u043d\u0430 \u0446\u044c\u043e\u043c\u0443 \u0441\u0430\u0439\u0442\u0456, \u0432\u0456\u0434\u043a\u0440\u0438\u0439 \u043f\u0440\u043e\u0435\u043a\u0442 \u0432 replit.com")}else {if(!localStorage["getItem"]("nick__androidx")){let _0x24a0x3=prompt("\u0412\u0432\u0435\u0434\u0438 \u0441\u0432\u0456\u0439 \u043d\u0456\u043a \u044f\u043a\u0438\u0439 \u0442\u0438 \u0432\u0438\u043a\u043e\u0440\u0438\u0441\u0442\u043e\u0432\u0443\u0454\u0448 \u0432 \u0440\u0435\u0434\u0430\u043a\u0442\u043e\u0440\u0456 RScript \u043b\u044f \u0434\u043e\u0441\u0442\u0443\u043f\u0443 \u0434\u043e \u0441\u0432\u043e\u0457\u0445 \u0434\u043e\u0434\u0430\u0442\u043a\u0456\u0432");if(_0x24a0x3){localStorage["setItem"]("nick__androidx",_0x24a0x3)}else {location["reload"]()}};let _0x24a0x4=document["createElement"]("div");_0x24a0x4["className"]= "css-36v8qi";_0x24a0x4["innerHTML"]= `<button type="button" style="display: none;" aria-label="Search &amp; run commands" class="css-s075ez"><img src="https://RScript.teleweb.repl.co/ios1.png"></button>`;document["querySelector"]("header .css-j7rju5")["prepend"](_0x24a0x4);let _0x24a0x5=document["createElement"]("button");_0x24a0x5["setAttribute"]("tabindex","-1");_0x24a0x5["className"]= "css-1yj7wgw";_0x24a0x5["id"]= "open_androidx";_0x24a0x5["innerHTML"]= `<div class="icon css-1oljaau" draggable="true" style="width: 38px; height: 38px;"><img src="https://RScript.teleweb.repl.co/ios1.png" style="width: 30px;"></div>
    <span class="text css-jqdc5i">Emulator</span>`;document["querySelector"]("#sidebar-section-content-dock > div > div")["appendChild"](_0x24a0x5);let _0x24a0x6=document["createElement"]("button");_0x24a0x6["setAttribute"]("tabindex","-1");_0x24a0x6["className"]= "css-1yj7wgw";_0x24a0x6["id"]= "run_androidx";_0x24a0x6["innerHTML"]= `<div class="icon css-1oljaau" draggable="true" style="width: 38px; height: 38px;"><img src="https://RScript.teleweb.repl.co/photo_5408886834408310060_m.png"></div>
    <span class="text css-jqdc5i">Run Android</span>`;document["querySelector"]("#sidebar-section-content-dock > div > div")["appendChild"](_0x24a0x6);if(document["querySelector"]("#sidebar-section-header-dock")["getAttribute"]("aria-expanded")== `false`){document["querySelector"]("#sidebar-section-header-dock")["click"]()};document["querySelector"](".css-36v8qi button")["onclick"]= ()=>{document["querySelector"]("#main-content button[aria-label=\'New tab\']:last-child")["click"]();let _0x24a0x7=document["querySelectorAll"]("span.css-o4584k");for(let _0x24a0x8 of _0x24a0x7){if(_0x24a0x8["innerHTML"]== "New tab"){_0x24a0x8["innerHTML"]= "Emulator"}};setTimeout(()=>{document["querySelector"](".css-1guk1gr[style^=\'z-index: 5;\'] div")["remove"]()},200);let _0x24a0x9=document["createElement"]("img");_0x24a0x9["id"]= "em";_0x24a0x9["src"]= "https://RScript.teleweb.repl.co/coolezgif-3-8593342966.gif";_0x24a0x9["style"]["cssText"]= `
  width: 39%;
  display: block;
  margin: auto;
  border-radius: 20px;`;let _0x24a0xa=document["createElement"]("loading");_0x24a0xa["id"]= "loading_emul";_0x24a0xa["style"]["cssText"]= `text-align: center;
  position: absolute;
  display: block;
  left: 50%;
  top: 10%;
  transform: translate(-50%, 10%);
  font-size: 25px;
  width: 300px;`;_0x24a0xa["innerText"]= "LOADING EMULATOR...";document["querySelector"](".css-1guk1gr[style^=\'z-index: 5;\']")["appendChild"](_0x24a0xa);document["querySelector"](".css-1guk1gr[style^=\'z-index: 5;\']")["appendChild"](_0x24a0x9);setTimeout(()=>{document["querySelector"]("#em")["remove"]();document["querySelector"]("#loading_emul")["remove"]();let _0x24a0xb=document["createElement"]("style");_0x24a0xb["id"]= "androidx_style";_0x24a0xb["innerHTML"]= `img.btn_home {
    width: 70px;
    position: absolute;
    top: 82%;
    left: -45%;
  filter: opacity(0.5);
  pointer-events: none;
}
#run_androidx img {
  width: 43px;
}
#open_androidx img {
  width: 30px;
}
.css-s075ez img {
  width: 22px;
}
img.btn_apps {
  width: 45px;
  position: absolute;
  top: 76%;
  left: -11%;
  filter: opacity(0.5);
  pointer-events: none;
}
img.btn_back {
  position: absolute;
  width: 48px;
  top: 66%;
  left: -20%;
  filter: opacity(0.5);
  pointer-events: none;
}
img.btn_reload {
  position: absolute;
  width: 60px;
  top: 40%;
  left: -30%;
  filter: opacity(0.5);
  pointer-events: none;
}
.__android_after {
  text-align: center;
  display: block;
  position: absolute;
  width: 0px;
  overflow: hidden;
  color: lime;
  font-size: 25px;
  left: 50px;
  background: black;
  border: 4px hsl(120deg 100% 50%) solid;
  border-left: none;
  border-right: none;
  filter: drop-shadow(2px 4px 6px black);
  box-shadow: 0px 0px 10px;
  transition: .1s linear;
}
#androidx .__android_after {
  text-align: center;
  display: block;
  position: absolute;
  width: 0px;
  overflow: hidden;
  color: lime;
  font-size: 25px;
  right: 40px;
  background: black;
  border: 4px hsl(120deg 100% 50%) solid;
  border-left: none;
  border-right: none;
  filter: drop-shadow(2px 4px 6px black);
  box-shadow: 0px 0px 10px;
  transition: .1s linear;
}
android-news-o {
  display: block;
  position: relative;
  width: 34.5%;
  margin-left: auto;
  top: 75%;
  /* right: 8px; */
  height: 20%;
  border-bottom: 2px hsl(120deg 100% 50%) solid;
  border-right: 2px hsl(120deg 100% 50%) solid;
  text-align: center;
  color: lime;
  word-break: break-all;
  overflow: scroll;
  left: 33%;
}
img#__device_online {
  width: 36px;
}
#resz {
  transform: rotateZ(270deg);
    position: absolute;
    left: -24px;
    top: 152px;
    width: 80px;
}
#rotate, #inv {
  width: inherit;
  position: absolute;
}
#inv {
  top: 80px;
  font-size: 15px;
}
img.__screenshoot_o {
  width: 31px;
/*   position: absolute; */
  left: 3px;
  cursor: pointer;
/*   top: -6px; */
/*   bottom: 0%; */
}
img.btn_inet {
  width: 43px;
  position: absolute;
  top: 50%;
  left: -3px;
}
::-webkit-scrollbar {
  display: none;
}
.__android_after.rel {
  top: 40%;
}
span.__android_after.bac {
  top: 67%;
}
span.__android_after.app {
  top: 74%;
}
span.__android_after.hom {
  top: 83%;
}
.__android_after.clo {
  top: 0px;
}
span.__android_after.__rel {
  top:5%;
}
span.__android_after.__inv {
  top: 15%;
}
span.__android_after.__resz {
  top: 23%;
}
.__android_after.rel.show1 {
  width: 202px;
}
span.__android_after.bac.show2 {
  width: fit-content;
}
span.__android_after.app.show3 {
  width: 300px;
}
span.__android_after.hom.show4 {
  width: 222px;
}
.__android_after.clo.show5 {
  width: 200px;
}
span.__android_after.__rel.show6 {
  width: 200px;
}
span.__android_after.__inv.show7 {
  width: 200px;
}
span.__android_after.__resz.show8 {
  width: 200px;
}
img#__device_offline {
  width: 36px;
}
sp {
  display: block;
  position: absolute;
  /* top: 221px; */
  bottom: 7px;
  left: 4px;
  font-size: 20px;
}
sp:hover {
  cursor: move;
}`;let _0x24a0xc=document["createElement"]("div");_0x24a0xc["id"]= "androidx";_0x24a0xc["className"]= "andr ui-draggable ui-draggable-handle";_0x24a0xc["setAttribute"]("style",`width: 36px;height: 470px;/* border: 2px solid hsl(110deg 100% 50%); */position: absolute;top: 85px;right: 432px;overflow: visible;background: hsl(70deg 16% 70%);border-radius: 20px;box-shadow: 0px 0px 20px 5px lime;`);_0x24a0xc["innerHTML"]= `<close><img src="https://RScript.teleweb.repl.co/www/js/off.png" class="close_android" id="__device_online"><span class="__android_after clo">вимкнути девайс</span>
    </close><br><input type="range" id="resz" value="1" max="1" step="0.1"><span class="__android_after __resz">яскравість екрану</span>
    <button id="inv" style="color: black; background: white;">INV</button><span class="__android_after __inv">інвертувати кольори в екрані</span>
    <button id="rotate">⟲</button><span class="__android_after __rel">перезавантажити девайс</span>
      <img src="https://RScript.teleweb.repl.co/www/__mobile/__constructor/__panel/wifi.png" class="btn_inet" style="filter: opacity(1); pointer-events: auto;">
    <img src="https://RScript.teleweb.repl.co/www/__mobile/__constructor/__panel/reload_app.png" class="btn_reload" style="filter: opacity(1); pointer-events: auto;"><span class="__android_after rel">перезавантажити додаток в девайсі</span>
    <img src="https://RScript.teleweb.repl.co/www/__mobile/__constructor/__down_panel/back.png" class="btn_back" style="filter: opacity(1); pointer-events: auto;"><span class="__android_after bac">назад</span>
    <img src="https://RScript.teleweb.repl.co/www/__mobile/__constructor/__down_panel/apps.png" class="btn_apps" style="filter: opacity(1); pointer-events: auto;"><span class="__android_after app">всі відкриті додатки в девайсі</span>
    <img src="https://RScript.teleweb.repl.co/www/__mobile/__constructor/__down_panel/break_all.png" class="btn_home" style="filter: opacity(1); pointer-events: auto;"><span class="__android_after hom">закрити додаток в девайсі</span>
    <sp title="MOVE">🟢</sp>
    <iframe src="https://iphone.teleweb.repl.co/www/" id="windowAndroid" style="width: 331px;height: 660px;position: relative;left: 55px;top: -56px;box-shadow: 0px 0px 10px;border-radius: 50px;border: 3px solid rgb(255, 0, 0);" loading="lazy"></iframe>`;let _0x24a0xd=document["createElement"]("script");let _0x24a0xe=document["createElement"]("script");_0x24a0xd["id"]= "scr_x1";_0x24a0xe["id"]= "scr_x2";document["querySelector"](".css-1guk1gr[style^=\'z-index: 5;\']")["appendChild"](_0x24a0xc);document["body"]["appendChild"](_0x24a0xb);function _0x24a0xf(_0x24a0x10){var _0x24a0x11=document["querySelectorAll"](_0x24a0x10),_0x24a0x12,_0x24a0x13,_0x24a0x14,_0x24a0x15;for(let _0x24a0x16 of _0x24a0x11){_0x24a0x16["addEventListener"]('mousedown',function(_0x24a0x17){_0x24a0x17["preventDefault"]();_0x24a0x12= this["parentNode"]["offsetLeft"];_0x24a0x13= this["parentNode"]["offsetTop"];_0x24a0x14= _0x24a0x17["pageX"];_0x24a0x15= _0x24a0x17["pageY"];this["addEventListener"]('mousemove',_0x24a0x19,false);window["addEventListener"]('mouseup',function(){_0x24a0x16["removeEventListener"]('mousemove',_0x24a0x19,false)},false)},false);_0x24a0x16["addEventListener"]('touchstart',function(_0x24a0x17){_0x24a0x17["preventDefault"]();_0x24a0x12= this["parentNode"]["offsetLeft"];_0x24a0x13= this["parentNode"]["offsetTop"];var _0x24a0x18=_0x24a0x17["touches"];_0x24a0x14= _0x24a0x18[0]["pageX"];_0x24a0x15= _0x24a0x18[0]["pageY"];this["addEventListener"]('touchmove',_0x24a0x1a,false);window["addEventListener"]('touchend',function(_0x24a0x17){_0x24a0x17["preventDefault"]();_0x24a0x16["removeEventListener"]('touchmove',_0x24a0x1a,false)},false)},false);function _0x24a0x19(_0x24a0x17){this["parentNode"]["style"]["left"]= _0x24a0x12+ _0x24a0x17["pageX"]- _0x24a0x14+ 'px';this["parentNode"]["style"]["top"]= _0x24a0x13+ _0x24a0x17["pageY"]- _0x24a0x15+ 'px'}function _0x24a0x1a(_0x24a0x17){var _0x24a0x1b=_0x24a0x17["touches"];this["parentNode"]["style"]["left"]= _0x24a0x12+ _0x24a0x1b[0]["pageX"]- _0x24a0x14+ 'px';this["parentNode"]["style"]["top"]= _0x24a0x13+ _0x24a0x1b[0]["pageY"]- _0x24a0x15+ 'px'}}}_0x24a0xf("#androidx.andr sp");document["querySelector"]("#androidx")["onmouseover"]= (_0x24a0x7)=>{if(_0x24a0x7["target"]["className"]== "btn_reload"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show1")}else {if(_0x24a0x7["target"]["className"]== "btn_back"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show2")}else {if(_0x24a0x7["target"]["className"]== "btn_apps"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show3")}else {if(_0x24a0x7["target"]["className"]== "btn_home"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show4")}else {if(_0x24a0x7["target"]["className"]== "close_android"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show5")}else {if(_0x24a0x7["target"]["id"]== "inv"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show7")}else {if(_0x24a0x7["target"]["id"]== "rotate"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show6")}else {if(_0x24a0x7["target"]["id"]== "resz"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["add"]("show8")}}}}}}}}};document["querySelector"]("#androidx")["onmouseout"]= (_0x24a0x7)=>{if(_0x24a0x7["target"]["className"]== "btn_reload"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show1")}else {if(_0x24a0x7["target"]["className"]== "btn_back"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show2")}else {if(_0x24a0x7["target"]["className"]== "btn_apps"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show3")}else {if(_0x24a0x7["target"]["className"]== "btn_home"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show4")}else {if(_0x24a0x7["target"]["className"]== "close_android"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show5")}else {if(_0x24a0x7["target"]["id"]== "inv"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show7")}else {if(_0x24a0x7["target"]["id"]== "rotate"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show6")}else {if(_0x24a0x7["target"]["id"]== "resz"){_0x24a0x7["target"]["nextElementSibling"]["classList"]["remove"]("show8")}}}}}}}}};document["querySelector"]("#androidx .btn_reload")["onclick"]= ()=>{document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"](`__reload_app-${localStorage["getItem"]("nick__androidx")}`,"https://Iphone.teleweb.repl.co")};document["querySelector"]("#androidx .btn_back")["onclick"]= ()=>{document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"](`go_back`,"https://Iphone.teleweb.repl.co")};document["querySelector"](".btn_inet")["onclick"]= ()=>{document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"]("__online","https://Iphone.teleweb.repl.co")};document["querySelector"]("#androidx .btn_apps")["onclick"]= ()=>{document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"](`show_apps`,"https://Iphone.teleweb.repl.co")};document["querySelector"]("#androidx #inv")["style"]["color"]= "black";document["querySelector"]("#androidx #inv")["style"]["background"]= "white";document["querySelector"]("#androidx.andr iframe")["onload"]= function(){this["contentWindow"]["postMessage"](`user-${localStorage["getItem"]("nick__androidx")}`,"https://Iphone.teleweb.repl.co");setTimeout(()=>{document["querySelector"]("#androidx .btn_apps")["style"]["cssText"]= document["querySelector"]("#androidx .btn_back")["style"]["cssText"]= document["querySelector"]("#androidx .btn_reload")["style"]["cssText"]= document["querySelector"]("#androidx .btn_home")["style"]["cssText"]= "filter: opacity(1); pointer-events: auto;"},8000)};document["querySelector"]("#androidx")["onclick"]= (_0x24a0x17)=>{let _0x24a0x1c=_0x24a0x17["target"];if(_0x24a0x1c["id"]== "rotate"){document["querySelector"]("#androidx iframe")["src"]= document["querySelector"]("#androidx iframe")["src"];document["querySelector"]("#androidx .close_android")["id"]= "__device_offline"}else {if(_0x24a0x1c["className"]== "close_android"){if(_0x24a0x1c["id"]== "__device_offline"){_0x24a0x1c["id"]= "__device_online";document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"]("__device_online","https://Iphone.teleweb.repl.co");document["querySelector"]("#androidx.andr .btn_reload")["style"]["cssText"]= `filter: opacity(1); pointer-events: auto;`;document["querySelector"]("#androidx.andr .btn_back")["style"]["cssText"]= `filter: opacity(1); pointer-events: auto;`;document["querySelector"]("#androidx.andr .btn_apps")["style"]["cssText"]= `filter: opacity(1); pointer-events: auto;`;document["querySelector"]("#androidx.andr .btn_home")["style"]["cssText"]= `filter: opacity(1); pointer-events: auto;`;document["querySelector"]("#androidx.andr .btn_inet")["style"]["cssText"]= `filter: opacity(1); pointer-events: auto;`}else {_0x24a0x1c["id"]= "__device_offline";document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"]("__device_offline","https://Iphone.teleweb.repl.co");document["querySelector"]("#androidx.andr .btn_reload")["style"]["cssText"]= `filter: opacity(.5); pointer-events: none;`;document["querySelector"]("#androidx.andr .btn_back")["style"]["cssText"]= `filter: opacity(.5); pointer-events: none;`;document["querySelector"]("#androidx.andr .btn_apps")["style"]["cssText"]= `filter: opacity(.5); pointer-events: none;`;document["querySelector"]("#androidx.andr .btn_home")["style"]["cssText"]= `filter: opacity(.5); pointer-events: none;`;document["querySelector"]("#androidx.andr .btn_inet")["style"]["cssText"]= `filter: opacity(.5); pointer-events: auto;`}}else {if(_0x24a0x1c["className"]== "btn_home"){document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"]("gohome","https://Iphone.teleweb.repl.co")}}}};document["querySelector"]("#androidx #resz")["oninput"]= function(){document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"](this["value"],"https://Iphone.teleweb.repl.co")};document["querySelector"]("#androidx #inv")["onclick"]= function(){if(this["style"]["color"]== "black"){document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"]("hello","https://Iphone.teleweb.repl.co");this["style"]["color"]= "white";this["style"]["background"]= "black"}else {document["querySelector"]("#androidx.andr iframe")["contentWindow"]["postMessage"]("helloo","https://Iphone.teleweb.repl.co");this["style"]["color"]= "black";this["style"]["background"]= "white"}};document["querySelector"]("#run_androidx")["onclick"]= ()=>{if(document["querySelector"]("iframe[title=\'webview\']")){if(document["querySelector"]("#androidx")){let _0x24a0x7=document["querySelectorAll"]("span.css-o4584k");for(let _0x24a0x8 of _0x24a0x7){if(_0x24a0x8["innerHTML"]== "Emulator"){_0x24a0x8["parentNode"]["click"]();break}};const _0x24a0x1d=document["querySelectorAll"]("#androidx");for(let _0x24a0xc of _0x24a0x1d){_0x24a0xc["lastChild"]["contentWindow"]["postMessage"](`__runApp{url:${document["querySelector"]("iframe[title=\'webview\']")["src"]}}`,"https://Iphone.teleweb.repl.co")}}else {document["querySelector"]("#open_androidx")["click"]();setTimeout(()=>{document["querySelector"]("#run_androidx")["click"]()},2100)}}else {alert("\u0417\u0430\u043f\u0443\u0441\u0442\u0438 \u043f\u0440\u043e\u0435\u043a\u0442 \u0441\u043f\u043e\u0447\u0430\u0442\u043a\u0443 \u043d\u0430\u0442\u0438\u0441\u043d\u0443\u0432\u0448\u0438 \u043d\u0430 \u0437\u0435\u043b\u0435\u043d\u0443 \u043a\u043d\u043e\u043f\u043a\u0443 Run")}};document["querySelector"]("#open_console")["onclick"]= ()=>{document["querySelector"]("#androidx")["style"]["display"]= "none";document["querySelector"](".column.cl2")["style"]["display"]= "block"};document["querySelector"]("#open_emulator")["onclick"]= ()=>{document["querySelector"]("#androidx")["style"]["display"]= "block";document["querySelector"](".column.cl2")["style"]["display"]= "none"};document["querySelector"]("#__run_web")["onclick"]= ()=>{document["querySelector"](".cl1")["style"]["display"]= "block";document["querySelector"]("#run")["click"]()}},2000)};document["querySelector"]("#open_androidx")["onclick"]= ()=>{document["querySelector"](".css-36v8qi button")["click"]()}}}